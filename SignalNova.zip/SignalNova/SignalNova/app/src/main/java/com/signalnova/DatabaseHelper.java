package com.signalnova;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

import java.util.List;
import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "signalnova.db";
    private static final int DB_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS Profits (" +
                "day TEXT PRIMARY KEY, " +
                "amount REAL)");

        db.execSQL("CREATE TABLE IF NOT EXISTS signals (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "pair TEXT," +
                "direction TEXT," +
                "reason TEXT," +
                "duration INTEGER," +
                "session TEXT," +
                "isVip INTEGER," +
                "generatedBy TEXT," +
                "timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)");

        db.execSQL("CREATE TABLE IF NOT EXISTS SignalResults (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "pair TEXT," +
                "status TEXT," +
                "isVip INTEGER," +
                "executed INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS Profits");
        db.execSQL("DROP TABLE IF EXISTS signals");
        db.execSQL("DROP TABLE IF EXISTS SignalResults");
        onCreate(db);
    }

    public void addProfit(String day, float amount) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("day", day);
        values.put("amount", amount);
        db.insertWithOnConflict("Profits", null, values, SQLiteDatabase.CONFLICT_REPLACE);
        db.close();
    }

    public float getProfit(String day) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT amount FROM Profits WHERE day = ?", new String[]{day});
        float result = 0f;
        if (cursor.moveToFirst()) {
            result = cursor.getFloat(0);
        }
        cursor.close();
        db.close();
        return result;
    }

    public void insertSignal(SmartSignal signal) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("pair", signal.getPair());
        values.put("direction", signal.getDirection());
        values.put("reason", signal.getReason());
        values.put("duration", signal.getDuration());
        values.put("session", signal.getSession());
        values.put("isVip", signal.isVip() ? 1 : 0);
        values.put("generatedBy", signal.getGeneratedBy());
        db.insert("signals", null, values);
        db.close();
    }

    public Cursor getAllSignals() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM signals ORDER BY timestamp DESC", null);
    }

    public Cursor getTodaySignals(String todayDate) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM signals WHERE DATE(timestamp) = ?", new String[]{todayDate});
    }

    public void insertSignalResult(SignalResult result) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("pair", result.getPair());
        values.put("status", result.getStatus());
        values.put("isVip", result.isVip() ? 1 : 0);
        values.put("executed", result.isExecuted() ? 1 : 0);
        db.insert("SignalResults", null, values);
        db.close();
    }

    public int getWinCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM SignalResults WHERE status = 'WIN'", null);
        int count = cursor.moveToFirst() ? cursor.getInt(0) : 0;
        cursor.close();
        db.close();
        return count;
    }

    public int getExecutedCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM SignalResults WHERE executed = 1", null);
        int count = cursor.moveToFirst() ? cursor.getInt(0) : 0;
        cursor.close();
        db.close();
        return count;
    }

    public List<SignalResult> getAllSignalResults() {
        List<SignalResult> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM SignalResults", null);

        if (cursor.moveToFirst()) {
            do {
                SignalResult result = new SignalResult(
                    cursor.getString(cursor.getColumnIndex("pair")),
                    cursor.getString(cursor.getColumnIndex("status")),
                    cursor.getInt(cursor.getColumnIndex("isVip")) == 1,
                    cursor.getInt(cursor.getColumnIndex("executed")) == 1
                );
                list.add(result);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return list;
    }

    // ✅ جلب التوصيات كـ List<SmartSignal>
    public List<SmartSignal> getAllSignalsList() {
        List<SmartSignal> list = new ArrayList<>();
        Cursor cursor = getReadableDatabase().rawQuery("SELECT * FROM signals ORDER BY timestamp DESC", null);
        if (cursor.moveToFirst()) {
            do {
                SmartSignal signal = new SmartSignal(
                    cursor.getString(cursor.getColumnIndex("pair")),
                    cursor.getString(cursor.getColumnIndex("direction")),
                    cursor.getString(cursor.getColumnIndex("reason")),
                    cursor.getInt(cursor.getColumnIndex("duration")),
                    cursor.getString(cursor.getColumnIndex("session")),
                    cursor.getInt(cursor.getColumnIndex("isVip")) == 1,
                    cursor.getString(cursor.getColumnIndex("generatedBy"))
                );
                list.add(signal);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }
}