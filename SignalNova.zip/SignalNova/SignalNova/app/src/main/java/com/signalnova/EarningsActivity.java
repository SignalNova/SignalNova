package com.signalnova;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import java.util.ArrayList;

public class EarningsActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ✅ إنشاء التصميم
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 40, 40, 40);
        layout.setBackgroundColor(Color.parseColor("#101010"));

        // ✅ عنوان الصفحة
        TextView title = new TextView(this);
        title.setText("💰 أرباح الأسبوع");
        title.setTextColor(Color.CYAN);
        title.setTextSize(22);
        layout.addView(title);

        // ✅ أرباح الأيام
        float[] profits = {5.2f, 6.5f, 3.0f, 7.1f, 8.3f, 6.8f, 9.0f}; // مثال أسبوعي
        String[] days = {"سبت", "أحد", "إثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة"};

        ArrayList<Entry> entries = new ArrayList<>();
        for (int i = 0; i < profits.length; i++) {
            entries.add(new Entry(i, profits[i]));
        }

        LineDataSet dataSet = new LineDataSet(entries, "الأرباح اليومية");
        dataSet.setColor(Color.GREEN);
        dataSet.setValueTextColor(Color.WHITE);
        dataSet.setLineWidth(2f);

        LineChart chart = new LineChart(this);
        chart.setData(new LineData(dataSet));
        chart.getDescription().setEnabled(false);
        chart.getLegend().setTextColor(Color.WHITE);
        chart.getXAxis().setTextColor(Color.WHITE);
        chart.getAxisLeft().setTextColor(Color.WHITE);
        chart.getAxisRight().setTextColor(Color.WHITE);
        chart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        chart.setMinimumHeight(600);

        layout.addView(chart);
        setContentView(layout);
    }
}
package com.signalnova;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import java.util.ArrayList;

public class EarningsActivity extends Activity {

    private final String[] days = {"سبت", "أحد", "إثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        DatabaseHelper db = new DatabaseHelper(this);

        // ✅ تحديث أرباح بناءً على توصيات فعلية (كمثال حالي)
        db.addProfit("إثنين", 4.5f);
        db.addProfit("خميس", 3.2f);
        db.addProfit("جمعة", 7.9f); // ← تم تنفيذ توصية رابحة من الذكاء الصناعي!

        // ✅ واجهة التصميم
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 40, 40, 40);
        layout.setBackgroundColor(Color.parseColor("#101010"));

        TextView title = new TextView(this);
        title.setText("📈 أرباحي الحقيقية");
        title.setTextColor(Color.CYAN);
        title.setTextSize(22);
        layout.addView(title);

        // ✅ الرسم البياني من البيانات الحقيقية
        ArrayList<Entry> entries = new ArrayList<>();
        for (int i = 0; i < days.length; i++) {
            float profit = db.getProfit(days[i]);
            entries.add(new Entry(i, profit));
        }

        LineDataSet dataSet = new LineDataSet(entries, "الأرباح اليومية");
        dataSet.setColor(Color.GREEN);
        dataSet.setValueTextColor(Color.WHITE);
        dataSet.setLineWidth(2f);

        LineChart chart = new LineChart(this);
        chart.setData(new LineData(dataSet));
        chart.getDescription().setEnabled(false);
        chart.getLegend().setTextColor(Color.WHITE);
        chart.getXAxis().setTextColor(Color.WHITE);
        chart.getAxisLeft().setTextColor(Color.WHITE);
        chart.getAxisRight().setTextColor(Color.WHITE);
        chart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        chart.setMinimumHeight(600);

        layout.addView(chart);
        setContentView(layout);
    }
}