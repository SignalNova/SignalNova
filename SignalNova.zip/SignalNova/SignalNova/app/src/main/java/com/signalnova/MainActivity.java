package com.signalnova;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 🟦 إعداد التصميم العام
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 40, 40, 40);
        layout.setBackgroundColor(Color.parseColor("#111111"));

        // 🟦 عنوان التطبيق
        TextView title = new TextView(this);
        title.setText("SignalNova - توصيات ملكية");
        title.setTextSize(22);
        title.setTextColor(0xFF00FFFF);
        title.setPadding(0, 0, 0, 40);
        layout.addView(title);

        // ✅ زر التوصيات
        Button btnSignals = new Button(this);
        btnSignals.setText("📡 التوصيات");
        btnSignals.setOnClickListener(v -> {
            startActivity(new Intent(this, SignalsActivity.class));
        });
        layout.addView(btnSignals);

        // ✅ زر الأرباح
        Button btnEarnings = new Button(this);
        btnEarnings.setText("💰 أرباحي");
        btnEarnings.setOnClickListener(v -> {
            startActivity(new Intent(this, EarningsActivity.class));
        });
        layout.addView(btnEarnings);

        // ✅ زر تقرير الشهر
        Button btnReport = new Button(this);
        btnReport.setText("🗓️ تقرير الشهر");
        btnReport.setOnClickListener(v -> {
            startActivity(new Intent(this, ReportsActivity.class));
        });
        layout.addView(btnReport);

        // ✅ زر ترتيب المستخدمين
        Button btnTopUsers = new Button(this);
        btnTopUsers.setText("🔝 ترتيب المستخدمين");
        btnTopUsers.setOnClickListener(v -> {
            startActivity(new Intent(this, TopUsersActivity.class));
        });
        layout.addView(btnTopUsers);

        // ✅ زر نتائج التوصيات
        Button resultsBtn = new Button(this);
        resultsBtn.setText("📊 نتائج التوصيات");
        resultsBtn.setOnClickListener(v -> {
            startActivity(new Intent(this, ResultsActivity.class));
        });
        layout.addView(resultsBtn);

        // ✅ زر تنبيه توصية
        Button alertBtn = new Button(this);
        alertBtn.setText("📢 تنبيه توصية تداول الآن");
        alertBtn.setTextColor(Color.WHITE);
        alertBtn.setBackgroundColor(Color.parseColor("#FF5722"));
        alertBtn.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, com.signalnova.premiumai.AlertActivity.class));
        });
        layout.addView(alertBtn);

        // ✅ زر الشروط والخصوصية
        Button termsBtn = new Button(this);
        termsBtn.setText("📜 الشروط والخصوصية");
        termsBtn.setOnClickListener(v -> {
            startActivity(new Intent(this, com.signalnova.premiumai.TermsActivity.class));
        });
        layout.addView(termsBtn);

        // ✅ زر الأسئلة الشائعة
        Button faqBtn = new Button(this);
        faqBtn.setText("❓ الأسئلة الشائعة");
        faqBtn.setOnClickListener(v -> {
            startActivity(new Intent(this, com.signalnova.premiumai.FAQActivity.class));
        });
        layout.addView(faqBtn);

        // ✅ زر من نحن
        Button aboutBtn = new Button(this);
        aboutBtn.setText("👥 من نحن");
        aboutBtn.setOnClickListener(v -> {
            startActivity(new Intent(this, com.signalnova.premiumai.AboutUsActivity.class));
        });
        layout.addView(aboutBtn);

        // ✅ إعلان VIP إذا المستخدم ليس VIP
        boolean isVipUser = false; // هاد لاحقاً تجيبه من قاعدة البيانات
        if (!isVipUser) {
            TextView adBanner = new TextView(this);
            adBanner.setText("🔥 عرض خاص: اشترك الآن واحصل على 7 أيام VIP!");
            adBanner.setBackgroundColor(0xFF222222);
            adBanner.setTextColor(0xFFFFD700);
            adBanner.setPadding(16, 16, 16, 16);
            layout.addView(adBanner);
        }

        setContentView(layout);
    }
}
Button contactBtn = new Button(this);
contactBtn.setText("📩 تواصل معنا");
layout.addView(contactBtn);

contactBtn.setOnClickListener(v -> {
    startActivity(new Intent(this, ContactUsActivity.class));
});
Button suggestBtn = new Button(this);
suggestBtn.setText("💡 اقترح ميزة جديدة");
layout.addView(suggestBtn);

suggestBtn.setOnClickListener(v -> {
    startActivity(new Intent(this, FeatureSuggestionActivity.class));
});
Button earningsBtn = new Button(this);
earningsBtn.setText("💰 أرباح الأسبوع");
layout.addView(earningsBtn);

earningsBtn.setOnClickListener(v -> {
    startActivity(new Intent(this, EarningsActivity.class));
});