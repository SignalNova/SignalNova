package com.signalnova;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.ViewGroup.LayoutParams;

import java.util.List;

public class PerformanceAnalysisActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ✅ إعداد التصميم
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 40, 40, 40);
        layout.setBackgroundColor(Color.parseColor("#101010"));

        TextView title = new TextView(this);
        title.setText("📈 تحليل الأداء الشخصي");
        title.setTextColor(Color.CYAN);
        title.setTextSize(22);
        title.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        layout.addView(title);

        DatabaseHelper db = new DatabaseHelper(this);
        List<SignalResult> results = db.getAllSignalResults(); // ← نحصل على نتائج التوصيات

        int total = results.size();
        int executed = 0;
        int win = 0;
        int loss = 0;

        for (SignalResult res : results) {
            if (res.getStatus().equals("WIN")) {
                executed++;
                win++;
            } else if (res.getStatus().equals("LOSS")) {
                executed++;
                loss++;
            }
        }

        int successRate = (executed > 0) ? (win * 100 / executed) : 0;

        TextView stats = new TextView(this);
        stats.setTextColor(Color.WHITE);
        stats.setTextSize(18);
        stats.setText(
                "📬 التوصيات الكلية: " + total + "\n" +
                "✅ تم تنفيذها: " + executed + "\n" +
                "🔥 عدد الصفقات الرابحة: " + win + "\n" +
                "🔻 عدد الصفقات الخاسرة: " + loss + "\n" +
                "📊 نسبة النجاح: " + successRate + "%\n\n" +
                generateAdvice(successRate)
        );

        layout.addView(stats);
        setContentView(layout);
    }

    // ✅ نصائح مخصصة حسب نسبة النجاح
    private String generateAdvice(int successRate) {
        if (successRate >= 80) {
            return "🎯 أداء ممتاز! حافظ على استراتيجيتك 🔥";
        } else if (successRate >= 60) {
            return "📈 أداء جيد، راجع بعض الصفقات لتطوير قراراتك.";
        } else if (successRate >= 40) {
            return "⚠️ تحتاج لتحسين قرارات الدخول. جرب استراتيجيات أبطأ.";
        } else {
            return "🔍 راجع كل توصية قبل التنفيذ. لا تتسرع! جرب حساب تجريبي.";
        }
    }
}