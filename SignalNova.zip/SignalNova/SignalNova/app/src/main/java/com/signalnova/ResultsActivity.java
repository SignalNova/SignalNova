package com.signalnova;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import java.util.ArrayList;
import java.util.List;

public class ResultsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupUI();
    }

    private void setupUI() {
        LinearLayout layout = createMainLayout();

        addTitle(layout, "تقرير الأداء");
        setupChart(layout);
        displaySignals(layout);

        setContentView(layout);
    }

    private LinearLayout createMainLayout() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(Color.parseColor("#111111"));
        layout.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));
        return layout;
    }

    private void addTitle(LinearLayout layout, String titleText) {
        TextView title = new TextView(this);
        title.setText(titleText);
        title.setTextSize(20);
        title.setTextColor(Color.CYAN);
        layout.addView(title);
    }

    private void setupChart(LinearLayout layout) {
        try {
            BarChart chart = new BarChart(this);
            chart.setData(createChartData());
            configureChartAppearance(chart);
            layout.addView(chart);
        } catch (Exception e) {
            addErrorView(layout, "تعذر تحميل الرسم البياني");
        }
    }

    private BarData createChartData() {
        ArrayList<BarEntry> entries = new ArrayList<>();
        entries.add(new BarEntry(0, 15));
        entries.add(new BarEntry(1, 22));
        entries.add(new BarEntry(2, 18));

        BarDataSet dataSet = new BarDataSet(entries, "الأرباح اليومية");
        dataSet.setColors(Color.GREEN);
        return new BarData(dataSet);
    }

    private void configureChartAppearance(BarChart chart) {
        chart.setMinimumHeight(dpToPx(300));
        chart.getDescription().setEnabled(false);
        chart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
    }

    private void displaySignals(LinearLayout layout) {
        try {
            List<SmartSignal> signals = new DatabaseHelper(this).getAllSignals();
            for (SmartSignal signal : signals) {
                addSignalView(layout, signal);
            }
        } catch (Exception e) {
            addErrorView(layout, "تعذر تحميل البيانات");
        }
    }

    private void addSignalView(LinearLayout layout, SmartSignal signal) {
        TextView view = new TextView(this);
        view.setText(formatSignal(signal));
        view.setTextColor(Color.WHITE);
        view.setPadding(dpToPx(8), dpToPx(12), dpToPx(8), dpToPx(12));
        view.setBackgroundColor(Color.parseColor("#252525"));
        layout.addView(view);
    }

    private String formatSignal(SmartSignal signal) {
        return String.format(
            "الزوج: %s\nالاتجاه: %s\nالمدة: %d ثانية",
            signal.getPair(),
            signal.getDirection(),
            signal.getDuration()
        );
    }

    private void addErrorView(LinearLayout layout, String message) {
        TextView errorView = new TextView(this);
        errorView.setText(message);
        errorView.setTextColor(Color.RED);
        layout.addView(errorView);
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }
}
