package com.signalnova;

import java.util.Random;

public class SignalGenerator {

    private static final String[] reasons = {
        "شمعة انعكاسية 🔄 + RSI تحت 30 + دعم قوي 💪",
        "RSI فوق 70 + شمعة شهاب 📉 + مقاومة قوية 🔺",
        "تقاطع EMA 🔀 + ظل طويل + كسر وهمي",
        "شمعة مطرقة + إشارات تشبع + تقلب عالي 🔥"
    };

    private static final String[] sessions = {"Europe", "US"};

    public static SmartSignal generateSmartSignal() {
        Random rand = new Random();

        String pair = "EUR/USD";
        String direction = rand.nextBoolean() ? "BUY" : "SELL";
        String reason = reasons[rand.nextInt(reasons.length)];
        int duration = (rand.nextInt(4) + 1) * 30; // 30, 60, 90, 120 ثانية
        boolean isVip = true;
        String session = sessions[rand.nextInt(sessions.length)];
        String generatedBy = "AI";

        return new SmartSignal(pair, direction, reason, duration, isVip, session, generatedBy);
    }
}