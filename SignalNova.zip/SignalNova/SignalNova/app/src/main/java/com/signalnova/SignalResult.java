package com.signalnova;

public class SignalResult {

    private String pair;        // مثل EUR/USD
    private String status;      // WIN أو LOSS أو NOT_EXECUTED
    private boolean isVip;      // هل التوصية VIP فقط
    private boolean executed;   // هل تم تنفيذ التوصية

    public SignalResult() {
        // مُنشئ فارغ (ضروري عند استخدام قاعدة البيانات)
    }

    public SignalResult(String pair, String status, boolean isVip, boolean executed) {
        this.pair = pair;
        this.status = status;
        this.isVip = isVip;
        this.executed = executed;
    }

    // ✅ Getters
    public String getPair() {
        return pair;
    }

    public String getStatus() {
        return status;
    }

    public boolean isVip() {
        return isVip;
    }

    public boolean isExecuted() {
        return executed;
    }

    // ✅ Setters
    public void setPair(String pair) {
        this.pair = pair;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setVip(boolean vip) {
        isVip = vip;
    }

    public void setExecuted(boolean executed) {
        this.executed = executed;
    }
}