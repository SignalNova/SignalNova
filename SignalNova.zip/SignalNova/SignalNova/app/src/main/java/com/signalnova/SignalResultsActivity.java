package com.signalnova;

import android.app.Activity; import android.os.Bundle; import android.widget.TextView; import android.widget.LinearLayout; import android.graphics.Color;

public class SignalResultsActivity extends Activity {

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    // إعداد الواجهة
    LinearLayout layout = new LinearLayout(this);
    layout.setOrientation(LinearLayout.VERTICAL);
    layout.setPadding(40, 40, 40, 40);
    layout.setBackgroundColor(Color.parseColor("#121212"));

    TextView title = new TextView(this);
    title.setText("📊 نتائج التوصيات");
    title.setTextColor(Color.CYAN);
    title.setTextSize(22);
    layout.addView(title);

    // ربط بقاعدة البيانات
    DatabaseHelper db = new DatabaseHelper(this);

    // إظهار عدد التوصيات الرابحة
    int winCount = db.getWinCount();

    TextView resultText = new TextView(this);
    resultText.setTextColor(Color.WHITE);
    resultText.setTextSize(18);
    resultText.setText("✅ عدد التوصيات الرابحة: " + winCount);
    layout.addView(resultText);

    setContentView(layout);
}

}

package com.signalnova;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;

public class SignalResultsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        DatabaseHelper db = new DatabaseHelper(this);

        // 🔢 قراءة القيم
        int winCount = db.getWinCount();           // ✅ عدد التوصيات الرابحة
        int executedCount = db.getExecutedCount(); // ✅ عدد التوصيات المنفذة

        int winRate = 0;
        if (executedCount > 0) {
            winRate = (int) (((float) winCount / executedCount) * 100);
        }

        // 🎨 الواجهة
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(60, 60, 60, 60);
        layout.setBackgroundColor(Color.parseColor("#101010"));

        TextView title = new TextView(this);
        title.setText("📊 أداء التوصيات");
        title.setTextColor(Color.CYAN);
        title.setTextSize(22);
        layout.addView(title);

        TextView resultText = new TextView(this);
        resultText.setTextColor(Color.WHITE);
        resultText.setTextSize(18);
        resultText.setText(
                "✅ عدد التوصيات المنفذة: " + executedCount + "\n" +
                "🏆 عدد الرابحة: " + winCount + "\n" +
                "📈 نسبة النجاح: " + winRate + "%"
        );

        layout.addView(resultText);
        setContentView(layout);
    }
}
package com.signalnova;

import android.app.Activity; import android.os.Bundle; import android.widget.LinearLayout; import android.widget.TextView; import android.graphics.Color; import android.view.ViewGroup; import android.view.Gravity;

public class SignalResultsActivity extends Activity {

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    // ⚙️ الاتصال بقاعدة البيانات
    DatabaseHelper db = new DatabaseHelper(this);

    // 🔢 قراءة القيم
    int winCount = db.getWinCount();           // ✅ عدد التوصيات الرابحة
    int executedCount = db.getExecutedCount(); // ✅ عدد التوصيات المنفذة

    int winRate = 0;
    if (executedCount > 0) {
        winRate = (int) (((float) winCount / executedCount) * 100);
    }

    // 🎨 تصميم الواجهة
    LinearLayout layout = new LinearLayout(this);
    layout.setOrientation(LinearLayout.VERTICAL);
    layout.setPadding(60, 60, 60, 60);
    layout.setBackgroundColor(Color.parseColor("#101010"));
    layout.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT));
    layout.setGravity(Gravity.CENTER);

    TextView title = new TextView(this);
    title.setText("📊 أداء التوصيات");
    title.setTextColor(Color.CYAN);
    title.setTextSize(24);
    title.setGravity(Gravity.CENTER);
    layout.addView(title);

    TextView resultText = new TextView(this);
    resultText.setTextColor(Color.WHITE);
    resultText.setTextSize(18);
    resultText.setGravity(Gravity.CENTER);
    resultText.setText(
            "✅ عدد التوصيات المنفذة: " + executedCount + "\n" +
            "🏆 عدد الرابحة: " + winCount + "\n" +
            "📈 نسبة النجاح: " + winRate + "%");

    layout.addView(resultText);
    setContentView(layout);
}

}


