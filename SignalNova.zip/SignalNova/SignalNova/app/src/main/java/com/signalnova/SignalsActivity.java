package com.signalnova;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.graphics.Color;

import java.util.Calendar;
import java.util.Locale;

public class SignalsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        boolean isVipUser = true; // لاحقاً من قاعدة بيانات أو اشتراك
        String session = getCurrentSession();

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 40, 40, 40);
        layout.setBackgroundColor(Color.parseColor("#111111"));

        TextView textView = new TextView(this);
        textView.setTextColor(Color.CYAN);
        textView.setTextSize(18);

        if (isVipUser && (session.equals("Europe") || session.equals("US"))) {

            // ✅ توليد التوصية تلقائياً
            SmartSignal signal = SignalGenerator.generateSmartSignal();

            // ✅ تخزين التوصية تلقائياً في قاعدة البيانات
            DatabaseHelper db = new DatabaseHelper(this);
            db.insertSignal(signal);

            // ✅ تحديد لغة الجهاز
            String language = Locale.getDefault().getLanguage();
            String signalMessage = "";

            if (language.equals("ar")) {
                signalMessage =
                        "📊 الزوج: " + signal.getPair() + "\n" +
                        (signal.getDirection().equals("BUY") ? "📈 الاتجاه: شراء\n" : "📉 الاتجاه: بيع\n") +
                        "🎯 التوصية:\n" + signal.getReason() + "\n" +
                        "⏱️ المدة: " + signal.getDuration() + " ثانية\n" +
                        "🕒 الجلسة: " + (signal.getSession().equals("US") ? "الأمريكية" : "الأوروبية") + "\n" +
                        (signal.isVip() ? "🔐 للمشتركين فقط" : "");
            } else {
                signalMessage =
                        "📊 Pair: " + signal.getPair() + "\n" +
                        (signal.getDirection().equals("BUY") ? "📈 Direction: BUY\n" : "📉 Direction: SELL\n") +
                        "🎯 Reason:\n" + signal.getReason() + "\n" +
                        "⏱️ Duration: " + signal.getDuration() + " sec\n" +
                        "🕒 Session: " + signal.getSession() + "\n" +
                        (signal.isVip() ? "🔐 VIP only" : "");
            }

            textView.setText(signalMessage);

        } else {
            textView.setText("🚫 حالياً لا توجد توصيات متاحة.\n💡 الجلسة الفعالة: الأوروبية أو الأمريكية فقط.\n🔐 التوصيات متوفرة للمشتركين.");
        }

        layout.addView(textView);
        setContentView(layout);
    }

    private String getCurrentSession() {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);

        if (hour >= 9 && hour <= 16) {
            return "Europe";
        } else if (hour >= 16 && hour <= 23) {
            return "US";
        } else {
            return "None";
        }
    }
}