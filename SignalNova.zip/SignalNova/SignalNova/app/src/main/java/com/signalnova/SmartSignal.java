package com.signalnova;

public class SmartSignal {
    private String pair;         // زوج العملات، مثل EUR/USD
    private String direction;    // BUY أو SELL
    private String reason;       // سبب التوصية
    private int duration;        // مدة الصفقة بالثواني
    private String session;      // جلسة التداول (أوروبية / أمريكية ...)
    private boolean isVip;       // هل التوصية VIP؟
    private String generatedBy;  // تم إنشاؤها بواسطة (ذكاء صناعي / يدوي ...)

    // ✅ Constructor عام كامل
    public SmartSignal(String pair, String direction, String reason, int duration,
                       String session, boolean isVip, String generatedBy) {
        this.pair = pair;
        this.direction = direction;
        this.reason = reason;
        this.duration = duration;
        this.session = session;
        this.isVip = isVip;
        this.generatedBy = generatedBy;
    }

    // ✅ Getters
    public String getPair() {
        return pair;
    }

    public String getDirection() {
        return direction;
    }

    public String getReason() {
        return reason;
    }

    public int getDuration() {
        return duration;
    }

    public String getSession() {
        return session;
    }

    public boolean isVip() {
        return isVip;
    }

    public String getGeneratedBy() {
        return generatedBy;
    }

    // ✅ Setters (اختياري حسب الحاجة)
    public void setPair(String pair) {
        this.pair = pair;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public void setSession(String session) {
        this.session = session;
    }

    public void setVip(boolean vip) {
        isVip = vip;
    }

    public void setGeneratedBy(String generatedBy) {
        this.generatedBy = generatedBy;
    }
}