package com.signalnova;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.graphics.Color;
import android.view.Gravity;

public class SmartSignalActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 🧱 واجهة احترافية
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(Color.parseColor("#101010"));
        layout.setPadding(40, 40, 40, 40);
        layout.setGravity(Gravity.START);

        // ✅ مثال لتوصية حقيقية (بترتيب صحيح)
        SmartSignal signal = new SmartSignal(
                "EUR/USD",
                "BUY",
                "شمعة انعكاسية 🔄 + تقاطع متوسطات EMA 📉 + دعم قوي 💪",
                60,
                "الأمريكية",
                true,
                "AI"
        );

        StringBuilder builder = new StringBuilder();
        builder.append("📊 الزوج: ").append(signal.getPair()).append("\n");
        builder.append("📈 الاتجاه: ").append(signal.getDirection().equals("BUY") ? "شراء" : "بيع").append("\n\n");
        builder.append("🎯 توصية خاصة:\n").append(signal.getReason()).append("\n\n");
        builder.append("⏱️ المدة: ").append(signal.getDuration()).append(" ثانية\n");
        builder.append("🕒 الجلسة: ").append(signal.getSession()).append("\n");

        if (signal.isVip()) {
            builder.append("🔐 للمشتركين فقط");
        }

        TextView textView = new TextView(this);
        textView.setText(builder.toString());
        textView.setTextSize(18);
        textView.setTextColor(Color.WHITE);
        layout.addView(textView);

        setContentView(layout);
    }
}