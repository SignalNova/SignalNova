package com.signalnova;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class TodaySignalsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        DatabaseHelper db = new DatabaseHelper(this);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 50, 50, 50);
        layout.setBackgroundColor(Color.parseColor("#0B0B0B"));

        TextView title = new TextView(this);
        title.setText("📅 توصيات اليوم:");
        title.setTextSize(22);
        title.setTextColor(Color.CYAN);
        layout.addView(title);

        // ✅ جلب التاريخ الحالي
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        // ✅ استعلام التوصيات حسب تاريخ اليوم
        Cursor cursor = db.getTodaySignals(today);

        if (cursor.getCount() == 0) {
            TextView emptyText = new TextView(this);
            emptyText.setText("🚫 لا توجد توصيات اليوم حتى الآن.");
            emptyText.setTextColor(Color.WHITE);
            layout.addView(emptyText);
        } else {
            while (cursor.moveToNext()) {
                String pair = cursor.getString(cursor.getColumnIndex("pair"));
                String direction = cursor.getString(cursor.getColumnIndex("direction"));
                String reason = cursor.getString(cursor.getColumnIndex("reason"));
                int duration = cursor.getInt(cursor.getColumnIndex("duration"));

                TextView signalView = new TextView(this);
                signalView.setTextColor(Color.WHITE);
                signalView.setTextSize(17);
                signalView.setText("📊 " + pair + " | " + direction + "\n🎯 " + reason + "\n⏱️ " + duration + " ثانية\n");
                signalView.setPadding(0, 20, 0, 20);
                layout.addView(signalView);
            }
        }

        cursor.close();
        setContentView(layout);
    }
}

package com.signalnova;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.database.Cursor;
import android.graphics.Color;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class TodaySignalsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 💽 قاعدة البيانات
        DatabaseHelper db = new DatabaseHelper(this);

        // 📆 تاريخ اليوم
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        Cursor cursor = db.getTodaySignals(today);

        // 🧱 الواجهة
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 50, 50, 50);
        layout.setBackgroundColor(Color.parseColor("#000000"));

        TextView title = new TextView(this);
        title.setText("📅 توصيات اليوم");
        title.setTextSize(22);
        title.setTextColor(Color.CYAN);
        layout.addView(title);

        if (cursor.moveToFirst()) {
            do {
                String pair = cursor.getString(cursor.getColumnIndex("pair"));
                String direction = cursor.getString(cursor.getColumnIndex("direction"));
                String reason = cursor.getString(cursor.getColumnIndex("reason"));
                int duration = cursor.getInt(cursor.getColumnIndex("duration"));
                String session = cursor.getString(cursor.getColumnIndex("session"));

                TextView t = new TextView(this);
                t.setTextColor(Color.WHITE);
                t.setTextSize(16);
                t.setText("🔹 " + pair + " | " + direction + " | " + duration + "s\n🎯 " + reason + "\n🕒 " + session + "\n");
                t.setPadding(0, 20, 0, 20);
                layout.addView(t);

            } while (cursor.moveToNext());
        } else {
            TextView empty = new TextView(this);
            empty.setText("🚫 لا توجد توصيات اليوم.");
            empty.setTextColor(Color.GRAY);
            layout.addView(empty);
        }

        cursor.close();
        setContentView(layout);
    }
}