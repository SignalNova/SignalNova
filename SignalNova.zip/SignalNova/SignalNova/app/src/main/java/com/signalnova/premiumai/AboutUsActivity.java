package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.graphics.Color;

public class AboutUsActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 40, 40, 40);
        layout.setBackgroundColor(Color.parseColor("#111111"));
        scroll.addView(layout);

        TextView title = new TextView(this);
        title.setText("👥 من نحن");
        title.setTextSize(22);
        title.setTextColor(Color.CYAN);
        layout.addView(title);

        TextView body = new TextView(this);
        body.setText(
            "تطبيق SignalNova هو نتاج عمل فريق محترف من خبراء التداول ومهندسي البرمجيات وذكاء صناعي متطور 🔥\n\n" +
            "نؤمن أن كل شخص يستحق فرصة للنجاح المالي، لذلك أنشأنا نظام توصيات يعتمد على تحليل الشموع والمؤشرات + ذكاء صناعي مُدرّب خصيصًا لزوج EUR/USD.\n\n" +
            "💡 التطبيق مدعوم أيضًا بجيش رقمي ذكي يشرف على دقة التوصيات وجودة الأداء.\n\n" +
            "📬 لأي استفسار، يمكنك التواصل معنا من خلال قسم الدعم داخل التطبيق أو عبر قناتنا على التليجرام الرسمية.\n\n" +
            "نسعى دائمًا لنكون الأفضل — معك نحو احتراف التداول 💼🚀"
        );
        body.setTextSize(16);
        body.setTextColor(Color.LTGRAY);
        body.setPadding(0, 20, 0, 0);
        layout.addView(body);

        setContentView(scroll);
    }
}