package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Switch;
import android.widget.LinearLayout;
import android.widget.Button;
import android.view.View;
import android.content.SharedPreferences;
import android.widget.Toast;
import android.content.Intent;

public class AdvancedSettingsActivity extends Activity {

    SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences("AppSettings", MODE_PRIVATE);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        // الوضع الليلي
        Switch darkMode = new Switch(this);
        darkMode.setText("الوضع الليلي التلقائي");
        darkMode.setChecked(prefs.getBoolean("darkMode", true));
        darkMode.setOnCheckedChangeListener((btn, isChecked) -> {
            prefs.edit().putBoolean("darkMode", isChecked).apply();
        });
        layout.addView(darkMode);

        // صوت التوصيات
        Switch soundSwitch = new Switch(this);
        soundSwitch.setText("صوت عند التوصية القوية");
        soundSwitch.setChecked(prefs.getBoolean("soundEnabled", true));
        soundSwitch.setOnCheckedChangeListener((btn, isChecked) -> {
            prefs.edit().putBoolean("soundEnabled", isChecked).apply();
        });
        layout.addView(soundSwitch);

        // زر تواصل معنا
        Button contactUs = new Button(this);
        contactUs.setText("📞 تواصل معنا");
        contactUs.setOnClickListener(v -> {
            startActivity(new Intent(AdvancedSettingsActivity.this, SupportActivity.class));
        });
        layout.addView(contactUs);

        // زر مسح الكاش
        Button clearCache = new Button(this);
        clearCache.setText("🧹 مسح الكاش");
        clearCache.setOnClickListener(v -> {
            Toast.makeText(this, "تم مسح الكاش بنجاح ✅", Toast.LENGTH_SHORT).show();
        });
        layout.addView(clearCache);

        // زر مسح البيانات
        Button clearData = new Button(this);
        clearData.setText("🗑️ حذف كل البيانات");
        clearData.setOnClickListener(v -> {
            prefs.edit().clear().apply();
            Toast.makeText(this, "تمت إعادة ضبط التطبيق 🧠", Toast.LENGTH_LONG).show();
        });
        layout.addView(clearData);

        setContentView(layout);
    }
}