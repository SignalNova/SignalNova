package com.signalnova.premiumai;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

public class AlertActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ✅ تشغيل صوت تنبيه من ملف raw
        MediaPlayer player = MediaPlayer.create(this, R.raw.signal_alert); 
        player.start();

        // ✅ عرض إشعار فوري داخل التطبيق
        Toast.makeText(this, "📢 توصية قوية الآن! افتح التطبيق فورًا ✅", Toast.LENGTH_LONG).show();

        // 🔚 إغلاق الشاشة تلقائيًا بعد 5 ثواني
        new Handler().postDelayed(() -> finish(), 5000);
    }
}