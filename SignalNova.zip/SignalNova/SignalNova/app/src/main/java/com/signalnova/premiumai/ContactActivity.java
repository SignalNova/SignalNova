package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import android.widget.LinearLayout;

public class ContactActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(24, 24, 24, 24);

        EditText message = new EditText(this);
        message.setHint("✍️ اكتب رسالتك هنا...");
        layout.addView(message);

        Button send = new Button(this);
        send.setText("📨 إرسال");
        layout.addView(send);

        send.setOnClickListener(v -> {
            Toast.makeText(this, "✅ تم إرسال الرسالة! شكراً لتواصلك معنا", Toast.LENGTH_LONG).show();
            message.setText("");
        });

        setContentView(layout);
    }
}