package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;

public class ContactUsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // واجهة رأسية
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 40, 40, 40);
        layout.setBackgroundColor(Color.parseColor("#111111"));

        // العنوان
        TextView title = new TextView(this);
        title.setText("📩 تواصل معنا عبر Telegram");
        title.setTextColor(Color.CYAN);
        title.setTextSize(22);
        layout.addView(title);

        // حقل الرسالة
        EditText messageBox = new EditText(this);
        messageBox.setHint("اكتب رسالتك هنا...");
        messageBox.setTextColor(Color.WHITE);
        messageBox.setHintTextColor(Color.GRAY);
        layout.addView(messageBox);

        // زر إرسال إلى Telegram
        Button sendBtn = new Button(this);
        sendBtn.setText("📨 إرسال عبر Telegram");
        sendBtn.setBackgroundColor(Color.parseColor("#0088cc")); // لون تلجرام
        sendBtn.setTextColor(Color.WHITE);
        layout.addView(sendBtn);

        sendBtn.setOnClickListener(v -> {
            String msg = messageBox.getText().toString();
            String telegramUser = "HASSN5364"; // بدون @

            String url = "https://t.me/" + telegramUser;
            if (!msg.isEmpty()) {
                url = "https://t.me/" + telegramUser + "?start=" + Uri.encode(msg);
            }

            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        });

        setContentView(layout);
    }
}