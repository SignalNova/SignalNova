package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.ScrollView;
import android.widget.LinearLayout;

public class EarningsActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(layout);

        // أرباح تجريبية - يتم استبدالها بقيم حقيقية من قاعدة البيانات لاحقاً
        String[] earnings = {
            "يناير 2025: +\$124",
            "فبراير 2025: +\$89",
            "مارس 2025: +\$145",
            "أبريل 2025: +\$170",
            "مايو 2025: +\$212",
            "يونيو 2025: +\$187"
        };

        for (String item : earnings) {
            TextView txt = new TextView(this);
            txt.setText(item);
            txt.setTextSize(18);
            txt.setPadding(20, 20, 20, 20);
            txt.setTextColor(0xFF00FFAA);
            layout.addView(txt);
        }

        setContentView(scroll);
    }
}
package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;

public class EarningsActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int referrals = 128; // القيمة الفعلية تُجلب من قاعدة البيانات
        String badge = ReferralManager.getUserBadge(referrals);
        double cash = ReferralManager.getCashReward(referrals);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        TextView t1 = new TextView(this);
        t1.setText("الإحالات: " + referrals + " 👥");

        TextView t2 = new TextView(this);
        t2.setText("وسامك: " + badge);

        TextView t3 = new TextView(this);
        t3.setText("مكافأتك المالية: " + cash + " $");

        layout.addView(t1);
        layout.addView(t2);
        layout.addView(t3);

        setContentView(layout);
    }
}