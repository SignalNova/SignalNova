package com.signalnova.premiumai;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FAQActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 📜 حاوية قابلة للتمرير
        ScrollView scrollView = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 40, 40, 40);
        layout.setBackgroundColor(Color.parseColor("#111111"));
        scrollView.addView(layout);

        // 📘 عنوان الصفحة
        TextView title = new TextView(this);
        title.setText("❓ الأسئلة الشائعة");
        title.setTextSize(22);
        title.setTextColor(Color.CYAN);
        layout.addView(title);

        // ❓ أسئلة وإجابات
        addQA(layout, "ما هو SignalNova؟", "تطبيق توصيات ذكي يساعدك على الربح من صفقات EUR/USD وغيرها بسهولة.");
        addQA(layout, "هل التوصيات مجانية؟", "نعم، توجد توصيات مجانية، ولديك خيار الاشتراك في VIP للوصول إلى إشارات أقوى.");
        addQA(layout, "كيف أُفعّل حسابي VIP؟", "يمكنك الدفع بالعملات الرقمية أو استخدام رمز ترويجي.");
        addQA(layout, "هل يمكنني الربح الحقيقي من التطبيق؟", "نعم إذا التزمت بالإدارة الصحيحة واتبعت التوصيات بدقة.");
        addQA(layout, "هل التطبيق يحتاج اتصال بالإنترنت؟", "نعم، التوصيات والإشعارات تحتاج اتصال دائم.");
        addQA(layout, "كيف أستلم التوصيات؟", "تصلك مباشرة داخل التطبيق عبر إشعارات حية.");
        addQA(layout, "أين أستطيع التواصل مع الدعم؟", "من خلال زر 'الدعم الفني' داخل التطبيق.");
        addQA(layout, "من يدير التطبيق؟", "فريق محترف + جيش رقمي ذكي تحت إشرافك.");

        setContentView(scrollView);
    }

    private void addQA(LinearLayout layout, String question, String answer) {
        TextView q = new TextView(this);
        q.setText("• " + question);
        q.setTextSize(18);
        q.setTextColor(Color.YELLOW);
        q.setPadding(0, 20, 0, 5);
        layout.addView(q);

        TextView a = new TextView(this);
        a.setText("↪ " + answer);
        a.setTextSize(16);
        a.setTextColor(Color.LTGRAY);
        layout.addView(a);
    }
}