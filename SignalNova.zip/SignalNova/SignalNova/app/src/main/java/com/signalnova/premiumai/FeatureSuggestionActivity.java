package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.graphics.Color;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

public class FeatureSuggestionActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 50, 50, 50);
        layout.setBackgroundColor(Color.parseColor("#111111"));

        EditText input = new EditText(this);
        input.setHint("💡 اقترح ميزة أو تعديل...");
        input.setHintTextColor(Color.GRAY);
        input.setTextColor(Color.WHITE);
        input.setBackgroundColor(Color.parseColor("#222222"));
        layout.addView(input);

        Button sendBtn = new Button(this);
        sendBtn.setText("📤 إرسال الاقتراح");
        layout.addView(sendBtn);

        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String suggestion = input.getText().toString().trim();
                if (suggestion.isEmpty()) {
                    Toast.makeText(FeatureSuggestionActivity.this, "⚠️ الرجاء كتابة الاقتراح أولاً", Toast.LENGTH_SHORT).show();
                } else {
                    // هنا ممكن ترسل الاقتراح لسيرفر أو تحزّنو مؤقتًا
                    Toast.makeText(FeatureSuggestionActivity.this, "✅ تم إرسال اقتراحك بنجاح", Toast.LENGTH_LONG).show();
                    input.setText("");
                }
            }
        });

        setContentView(layout);
    }
}
package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;

public class FeatureSuggestionActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 40, 40, 40);
        layout.setBackgroundColor(Color.parseColor("#111111"));

        TextView title = new TextView(this);
        title.setText("💡 اقترح ميزة جديدة");
        title.setTextSize(22);
        title.setTextColor(Color.CYAN);
        layout.addView(title);

        EditText suggestionBox = new EditText(this);
        suggestionBox.setHint("اكتب فكرتك هنا...");
        suggestionBox.setHintTextColor(Color.GRAY);
        suggestionBox.setTextColor(Color.WHITE);
        layout.addView(suggestionBox);

        Button sendBtn = new Button(this);
        sendBtn.setText("📤 إرسال الاقتراح عبر Telegram");
        sendBtn.setTextColor(Color.WHITE);
        sendBtn.setBackgroundColor(Color.parseColor("#0088cc"));
        layout.addView(sendBtn);

        sendBtn.setOnClickListener(v -> {
            String msg = suggestionBox.getText().toString();
            String telegramUser = "HASSN5364";

            String url = "https://t.me/" + telegramUser;
            if (!msg.isEmpty()) {
                url += "?start=" + Uri.encode("اقتراح ميزة:\n" + msg);
            }

            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        });

        setContentView(layout);
    }
}