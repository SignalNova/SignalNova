import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;



// 📤 أزرار المشاركة حسب المنصة
String shareText = "جرب SignalNova من هنا 👇\n" + referralLink;

// Telegram
Button telegramBtn = new Button(this);
telegramBtn.setText("📨 مشاركة عبر Telegram");
layout.addView(telegramBtn);
telegramBtn.setOnClickListener(v -> {
    Intent telegramIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/share/url?url=" + referralLink));
    startActivity(telegramIntent);
});

// WhatsApp
Button whatsappBtn = new Button(this);
whatsappBtn.setText("🟢 مشاركة عبر WhatsApp");
layout.addView(whatsappBtn);
whatsappBtn.setOnClickListener(v -> {
    Intent intent = new Intent(Intent.ACTION_SEND);
    intent.setType("text/plain");
    intent.setPackage("com.whatsapp");
    intent.putExtra(Intent.EXTRA_TEXT, shareText);
    try {
        startActivity(intent);
    } catch (android.content.ActivityNotFoundException e) {
        Toast.makeText(this, "❌ WhatsApp غير مثبت", Toast.LENGTH_SHORT).show();
    }
});

// Facebook
Button fbBtn = new Button(this);
fbBtn.setText("🔵 مشاركة عبر Facebook");
layout.addView(fbBtn);
fbBtn.setOnClickListener(v -> {
    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/sharer/sharer.php?u=" + referralLink));
    startActivity(intent);
});

// Twitter
Button twitterBtn = new Button(this);
twitterBtn.setText("🐦 مشاركة عبر Twitter");
layout.addView(twitterBtn);
twitterBtn.setOnClickListener(v -> {
    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/intent/tweet?text=" + Uri.encode(shareText)));
    startActivity(intent);
});