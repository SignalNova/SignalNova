package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public class MarketOpinionActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(layout);

        String[] thoughts = {
            "🤖 السوق حالياً يشهد زخم بيع مرتفع على EUR/USD بعد خبر البطالة الأمريكي",
            "📉 تراجع الذهب بسبب قوة الدولار صباحاً",
            "📊 عملة SMARTY في وضع شراء مثالي بفترة السيولة الأوروبية"
        };

        for (String thought : thoughts) {
            TextView txt = new TextView(this);
            txt.setText(thought);
            txt.setTextSize(18);
            txt.setPadding(18, 18, 18, 18);
            txt.setTextColor(0xFFFFFFFF);
            layout.addView(txt);
        }

        setContentView(scroll);
    }
}