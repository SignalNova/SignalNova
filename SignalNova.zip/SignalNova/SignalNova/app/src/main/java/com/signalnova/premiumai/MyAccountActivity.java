package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.Button;
import android.content.SharedPreferences;
import android.view.View;
import android.content.Intent;

public class MyAccountActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String username = prefs.getString("username", "user123");
        int referrals = prefs.getInt("referrals", 0);
        boolean isVIP = prefs.getBoolean("vip", false);
        int balance = referrals >= 1000 ? 10 : 0;

        String referralCode = "SN-" + username;
        String medal = referrals >= 1000 ? "🏅 ذهبي" : referrals >= 100 ? "🥈 فضي" : referrals >= 10 ? "🥉 برونزي" : "بدون وسام";

        TextView userTxt = new TextView(this);
        userTxt.setText("👤 المستخدم: " + username);
        layout.addView(userTxt);

        TextView refTxt = new TextView(this);
        refTxt.setText("🔗 رمز الإحالة: " + referralCode);
        layout.addView(refTxt);

        TextView vipTxt = new TextView(this);
        vipTxt.setText("🌟 الحالة: " + (isVIP ? "VIP مشترك" : "مجاني"));
        layout.addView(vipTxt);

        TextView rewardTxt = new TextView(this);
        rewardTxt.setText("💰 رصيدك الحالي: $" + balance);
        layout.addView(rewardTxt);

        TextView medalTxt = new TextView(this);
        medalTxt.setText("🎖️ وسامك: " + medal);
        layout.addView(medalTxt);

        Button logoutBtn = new Button(this);
        logoutBtn.setText("🚪 تسجيل الخروج");
        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs.edit().clear().apply();
                startActivity(new Intent(MyAccountActivity.this, MainActivity.class));
                finish();
            }
        });
        layout.addView(logoutBtn);

        setContentView(layout);
    }
}
package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.graphics.Color;

public class MyAccountActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 40, 40, 40);
        layout.setBackgroundColor(Color.parseColor("#111111"));

        // ✅ إعداد SharedPreferences
        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        // ✅ حفظ بيانات تجريبية (مرة واحدة)
        if (!prefs.contains("username")) {
            editor.putString("username", "Hassan");
            editor.putInt("referrals", 105); // عدد الإحالات
            editor.putBoolean("isVIP", true); // حالة VIP
            editor.apply();
        }

        // ✅ استرجاع البيانات
        String username = prefs.getString("username", "مستخدم غير معروف");
        int referrals = prefs.getInt("referrals", 0);
        boolean isVIP = prefs.getBoolean("isVIP", false);

        // 🏅 تحديد الوسام
        String badge = getUserBadge(referrals);
        double cashReward = getCashReward(referrals);

        // 👤 اسم المستخدم
        TextView userNameTxt = new TextView(this);
        userNameTxt.setText("👤 الاسم: " + username);
        userNameTxt.setTextColor(Color.WHITE);
        userNameTxt.setTextSize(18);
        layout.addView(userNameTxt);

        // 🌟 حالة VIP
        TextView vipStatusTxt = new TextView(this);
        vipStatusTxt.setText("🌟 الحالة: " + (isVIP ? "VIP ✅" : "غير مفعل ❌"));
        vipStatusTxt.setTextColor(isVIP ? Color.GREEN : Color.RED);
        vipStatusTxt.setTextSize(18);
        layout.addView(vipStatusTxt);

        // 🏅 الوسام
        TextView badgeTxt = new TextView(this);
        badgeTxt.setText("🏅 الوسام: " + badge);
        badgeTxt.setTextColor(Color.YELLOW);
        badgeTxt.setTextSize(18);
        layout.addView(badgeTxt);

        // 🔢 عدد الإحالات
        TextView referralTxt = new TextView(this);
        referralTxt.setText("👥 عدد الإحالات: " + referrals);
        referralTxt.setTextColor(Color.WHITE);
        referralTxt.setTextSize(18);
        layout.addView(referralTxt);

        // 🪙 مكافأة نقدية
        if (cashReward > 0) {
            TextView rewardTxt = new TextView(this);
            rewardTxt.setText("🪙 مكافأتك: " + cashReward + " USDT");
            rewardTxt.setTextColor(Color.CYAN);
            rewardTxt.setTextSize(18);
            layout.addView(rewardTxt);
        }

        setContentView(layout);
    }

    // 🏅 نظام الوسامات
    private String getUserBadge(int referrals) {
        if (referrals >= 1000) return "🔴 ملكي";
        else if (referrals >= 300) return "🟣 بلاتيني";
        else if (referrals >= 100) return "🔵 ذهبي";
        else if (referrals >= 30) return "🟠 فضي";
        else if (referrals >= 10) return "🟤 برونزي";
        return "⚪ لا وسام";
    }

    // 🪙 مكافأة نقدية (مثال)
    private double getCashReward(int referrals) {
        return referrals >= 1000 ? 10.0 : 0.0;
    }
}
package com.signalnova;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.Button;
import android.content.Intent;

public class MyAccountActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        // ✅ زر "من نحن"
        Button aboutBtn = new Button(this);
        aboutBtn.setText("👥 من نحن");
        layout.addView(aboutBtn);

        aboutBtn.setOnClickListener(v -> {
            startActivity(new Intent(this, com.signalnova.premiumai.AboutUsActivity.class));
        });

        setContentView(layout);
    }
}