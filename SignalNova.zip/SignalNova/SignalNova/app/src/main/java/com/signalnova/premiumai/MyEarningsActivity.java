package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public class MyEarningsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(layout);

        String[] earnings = {
            "💰 أرباحك اليوم: 5.2$",
            "🎁 إحالات نشطة: 324",
            "🏆 مكافآتك: VIP 10 أيام + خصم %30",
            "🟢 قابل للسحب: 3.7$"
        };

        for (String earn : earnings) {
            TextView txt = new TextView(this);
            txt.setText(earn);
            txt.setTextSize(18);
            txt.setPadding(20, 20, 20, 20);
            txt.setTextColor(0xFF00FF00); // أخضر فلورسنت
            layout.addView(txt);
        }

        setContentView(scroll);
    }
}