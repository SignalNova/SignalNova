package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public class NewsCenterActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(layout);

        String[] news = {
            "🇺🇸 مؤشر أسعار المستهلك (CPI) | التأثير المتوقع: 📈 الدولار يرتفع",
            "🇪🇺 قرار الفائدة الأوروبية | التأثير المتوقع: 📉 اليورو قد يتراجع",
            "🇬🇧 معدل البطالة في بريطانيا | التأثير المتوقع: 📈 الجنيه يصعد",
            "🌍 توترات جيوسياسية في آسيا | التأثير: تقلبات على الذهب"
        };

        for (String item : news) {
            TextView txt = new TextView(this);
            txt.setText(item);
            txt.setTextSize(17);
            txt.setPadding(20, 20, 20, 20);
            txt.setTextColor(0xFFECECEC);
            layout.addView(txt);
        }

        setContentView(scroll);
    }
}