package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public class OpportunitiesActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(layout);

        String[] opportunities = {
            "🎯 GBP/USD | شراء | 5 دقائق | ثقة: 🔥🔥🔥",
            "🎯 BTC/USD | بيع | 1 دقيقة | ثقة: 🔥🔥🔥🔥",
            "🎯 EUR/JPY | شراء | 3 دقائق | ثقة: 🔥🔥🔥"
        };

        for (String signal : opportunities) {
            TextView txt = new TextView(this);
            txt.setText(signal);
            txt.setTextSize(19);
            txt.setPadding(20, 20, 20, 20);
            txt.setTextColor(0xFF00FFAA); // لون أخضر مزرق
            layout.addView(txt);
        }

        setContentView(scroll);
    }
}