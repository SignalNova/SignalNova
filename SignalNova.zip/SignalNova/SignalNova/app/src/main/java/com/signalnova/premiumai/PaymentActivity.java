package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.widget.Button;
import android.widget.Toast;

public class PaymentActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Button payBtn = new Button(this);
        payBtn.setText("💰 اشترك الآن");

        payBtn.setOnClickListener(v -> {
            // افتح رابط NowPayments بمفتاحك الخاص
            String paymentUrl = "https://nowpayments.io/payment/?api_key=TAZU9oLPMWWDHurQn9pJQurVdkMa2ZfZdt";
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(paymentUrl));
            startActivity(i);

            Toast.makeText(this, "✅ يرجى إتمام الدفع وسيتم التفعيل تلقائيًا", Toast.LENGTH_LONG).show();
        });

        setContentView(payBtn);
    }
}