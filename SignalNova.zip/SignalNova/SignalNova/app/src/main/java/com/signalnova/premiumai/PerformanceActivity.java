package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public class PerformanceActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // إعداد الواجهة
        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 40, 40, 40);
        layout.setBackgroundColor(Color.parseColor("#111111"));
        scroll.addView(layout);

        // مثال على إحصائيات
        int totalSignals = 120;
        int successfulSignals = 91;
        int failedSignals = totalSignals - successfulSignals;
        float successRate = (successfulSignals * 100f) / totalSignals;

        // عناوين
        TextView title = new TextView(this);
        title.setText("📈 أداءي الشخصي");
        title.setTextColor(Color.CYAN);
        title.setTextSize(22);
        layout.addView(title);

        // عرض الإحصائيات
        addStat(layout, "✅ توصيات تم اتباعها:", totalSignals + " توصية");
        addStat(layout, "💰 توصيات ناجحة:", successfulSignals + " صفقة ناجحة");
        addStat(layout, "❌ توصيات خاسرة:", failedSignals + " صفقة خاسرة");
        addStat(layout, "🔥 نسبة النجاح:", String.format("%.1f%%", successRate));

        setContentView(scroll);
    }

    private void addStat(LinearLayout layout, String label, String value) {
        TextView stat = new TextView(this);
        stat.setText(label + "\n" + value + "\n");
        stat.setTextSize(18);
        stat.setTextColor(Color.WHITE);
        stat.setPadding(0, 30, 0, 10);
        layout.addView(stat);
    }
}