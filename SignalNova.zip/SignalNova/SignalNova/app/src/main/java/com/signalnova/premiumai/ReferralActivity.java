package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.content.SharedPreferences;

public class ReferralActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String username = prefs.getString("username", "user123");
        int referrals = prefs.getInt("referrals", 0);

        String referralCode = "SN-" + username;
        String reward = referrals >= 1000 ? "🎁 $10 جاهزة للسحب!" : "أكمل إلى 1000 إحالة للحصول على 10$ 💰";

        TextView codeTxt = new TextView(this);
        codeTxt.setText("رمز الإحالة الخاص بك: " + referralCode);
        codeTxt.setTextSize(18);
        layout.addView(codeTxt);

        TextView refCount = new TextView(this);
        refCount.setText("عدد الإحالات الفعالة: " + referrals);
        refCount.setTextSize(18);
        layout.addView(refCount);

        TextView rewardTxt = new TextView(this);
        rewardTxt.setText(reward);
        rewardTxt.setTextSize(18);
        layout.addView(rewardTxt);

        setContentView(layout);
    }
}