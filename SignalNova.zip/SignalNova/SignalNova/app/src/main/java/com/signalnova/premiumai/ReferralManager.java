package com.signalnova.premiumai;

public class ReferralManager {
    public static String getUserBadge(int referrals) {
        if (referrals >= 1000) return "🔴 ملكي";
        else if (referrals >= 300) return "🟣 بلاتيني";
        else if (referrals >= 100) return "🔵 ذهبي";
        else if (referrals >= 30) return "🟠 فضي";
        else if (referrals >= 10) return "🟤 برونزي";
        return "⚪ لا وسام";
    }

    public static double getCashReward(int referrals) {
        return referrals >= 1000 ? 10.0 : 0.0;
    }
}