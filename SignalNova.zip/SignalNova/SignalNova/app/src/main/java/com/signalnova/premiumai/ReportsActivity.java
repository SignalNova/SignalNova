package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.ScrollView;

public class ReportsActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        TextView report = new TextView(this);
        report.setTextSize(16);
        report.setPadding(24, 24, 24, 24);
        report.setTextColor(0xFFFFFFFF);

        String content = "📊 تقرير شهر يونيو 2025:\n\n"
                + "✅ التوصيات الناجحة: 82%\n"
                + "🔥 أعلى صفقة ربح: +$34\n"
                + "📈 متوسط الأرباح لكل مستخدم VIP: +$123\n"
                + "📉 أدنى نسبة خسارة: -$7\n"
                + "⚡ نشاط الذكاء الداخلي: قوي ومستقر";

        report.setText(content);
        scroll.addView(report);
        setContentView(scroll);
    }
}