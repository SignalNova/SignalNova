package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public class SessionAnalysisActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(layout);

        String[] sessionData = {
            "🕓 الجلسة الحالية: أوروبية",
            "💹 الأصل النشط: EUR/USD",
            "📈 فرص الشراء: GOLD / GBP/USD",
            "📉 فرص البيع: USD/JPY / SMARTY",
            "⚠️ تنبيه: خبر مهم الساعة 3:30م بتوقيتك"
        };

        for (String info : sessionData) {
            TextView txt = new TextView(this);
            txt.setText(info);
            txt.setTextSize(17);
            txt.setPadding(20, 20, 20, 20);
            txt.setTextColor(0xFFFFFFFF);
            layout.addView(txt);
        }

        setContentView(scroll);
    }
}