package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;

public class SignalsActivity extends Activity {

    SharedPreferences prefs;
    SharedPreferences.Editor editor;
    LinearLayout layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ScrollView و Layout
        ScrollView scroll = new ScrollView(this);
        layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(layout);

        setContentView(scroll);

        // SharedPreferences
        prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        editor = prefs.edit();
        boolean isVipUser = prefs.getBoolean("isVIP", false);

        // إذا ليس VIP، أظهر الإعلان وزر الرمز
        if (!isVipUser) {
            showAdAndPromoCodeEntry();
        }

        // عرض الإشارات
        showSignals();
    }

    private void showAdAndPromoCodeEntry() {
        TextView adBanner = new TextView(this);
        adBanner.setText("🔥 عرض خاص: أدخل رمز ترويجي للحصول على VIP!");
        adBanner.setBackgroundColor(0xFF222222);
        adBanner.setTextColor(0xFFFFD700);
        adBanner.setPadding(16, 16, 16, 16);
        layout.addView(adBanner);

        // حقل إدخال الرمز
        // حقل إدخال الرمز
		final EditText promoInput = new EditText(this); // ✅ اضفنا final
		promoInput.setHint("أدخل الرمز الترويجي هنا");
		layout.addView(promoInput);

        // زر تأكيد الرمز
        Button confirmBtn = new Button(this);
        confirmBtn.setText("✅ تأكيد الرمز");
        layout.addView(confirmBtn);

        confirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enteredCode = promoInput.getText().toString().trim();

                // ✅ قائمة الرموز المسموحة
                String[] validCodes = {"VIP100", "FREE7", "KING30"};

                boolean isValid = false;
                for (String code : validCodes) {
                    if (enteredCode.equalsIgnoreCase(code)) {
                        isValid = true;
                        break;
                    }
                }

                if (isValid) {
                    editor.putBoolean("isVIP", true);
                    editor.apply();
                    Toast.makeText(SignalsActivity.this, "✅ تم تفعيل VIP بنجاح!", Toast.LENGTH_LONG).show();
                    recreate(); // إعادة تحميل الصفحة بدون إعلان
                } else {
                    Toast.makeText(SignalsActivity.this, "❌ الرمز غير صالح!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void showSignals() {
        String[] signals = {
            "EUR/USD 📉 بيع | المدة: 1 دقيقة | ثقة: 🔥🔥🔥🔥",
            "XAU/USD 📈 شراء | المدة: 5 دقائق | ثقة: 🔥🔥🔥",
            "SMARTY 📊 شراء | المدة: 30 ثانية | ثقة: 🔥🔥🔥🔥🔥",
            "USOIL 📉 بيع | المدة: 3 دقائق | ثقة: 🔥🔥🔥🔥"
        };

        for (String signal : signals) {
            TextView txt = new TextView(this);
            txt.setText(signal);
            txt.setTextSize(18);
            txt.setPadding(24, 24, 24, 24);
            txt.setTextColor(0xFFFFFFFF);
            layout.addView(txt);
        }
    }
}
