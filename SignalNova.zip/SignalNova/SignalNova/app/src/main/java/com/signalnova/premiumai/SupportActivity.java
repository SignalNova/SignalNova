package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class SupportActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        EditText msg = new EditText(this);
        msg.setHint("اكتب مشكلتك هنا...");

        Button send = new Button(this);
        send.setText("📨 إرسال للدعم");

        send.setOnClickListener(v -> {
            Toast.makeText(this, "✅ تم إرسال الرسالة، سيتم الرد خلال 40 ثانية إلى 15 دقيقة", Toast.LENGTH_LONG).show();
            msg.setText("");
        });

        layout.addView(msg);
        layout.addView(send);
        setContentView(layout);
    }
}