package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.ScrollView;

public class TermsActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        TextView terms = new TextView(this);
        terms.setTextSize(16);
        terms.setPadding(24, 24, 24, 24);
        terms.setTextColor(0xFFCCCCCC);

        String content = "📜 شروط الاستخدام:\n\n"
                + "1. التطبيق مخصص للتوصيات التعليمية فقط.\n"
                + "2. لا نتحمل أي خسائر في الأسواق المالية.\n"
                + "3. يمنع إعادة نشر التوصيات دون إذن.\n"
                + "4. يخضع المحتوى للتحديث المستمر.\n"
                + "5. باستخدامك التطبيق، فأنت توافق على هذه الشروط.";

        terms.setText(content);
        scroll.addView(terms);
        setContentView(scroll);
    }
}
package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.graphics.Color;

public class TermsActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scrollView = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 40, 40, 40);
        layout.setBackgroundColor(Color.parseColor("#111111"));
        scrollView.addView(layout);

        TextView title = new TextView(this);
        title.setText("📜 الشروط وسياسة الخصوصية");
        title.setTextSize(22);
        title.setTextColor(Color.CYAN);
        layout.addView(title);

        TextView content = new TextView(this);
        content.setTextColor(Color.LTGRAY);
        content.setTextSize(16);
        content.setPadding(0, 20, 0, 0);

        String termsText = "باستخدامك لتطبيق SignalNova، فإنك توافق على الشروط التالية:\n\n" +
                "1. ❗ **الاستخدام:** يجب استخدام التطبيق لأغراض شخصية فقط وغير تجارية.\n" +
                "2. 🔒 **الخصوصية:** نحن نحترم خصوصيتك، ولا نقوم بمشاركة بياناتك مع أطراف خارجية.\n" +
                "3. 📶 **الاتصال:** يتطلب التطبيق اتصال دائم بالإنترنت للحصول على توصيات مباشرة.\n" +
                "4. 📈 **المخاطرة:** التداول يتضمن مخاطرة مالية. لسنا مسؤولين عن أي خسائر محتملة.\n" +
                "5. 🧠 **الذكاء الصناعي:** التوصيات مبنية على خوارزميات وتحليل تقني ذكي، لكنها ليست ضمانًا للربح.\n" +
                "6. 🛠️ **الدعم:** لأي استفسار أو مشكلة، يرجى التواصل مع فريق الدعم عبر التطبيق.\n" +
                "7. ✅ **الاشتراكات:** الاشتراكات في قسم VIP اختيارية وتُفعل بعد الدفع تلقائيًا.\n\n" +
                "باستمرارك في استخدام التطبيق، فإنك تؤكد موافقتك الكاملة على هذه الشروط.\n\n" +
                "شكراً لاستخدامك SignalNova! 🚀";

        content.setText(termsText);
        layout.addView(content);

        setContentView(scrollView);
    }
}