package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public class Top3LiveSignalsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(layout);

        String[] topSignals = {
            "🔥 EUR/USD | بيع | ثقة: 98%",
            "🔥 GOLD | شراء | ثقة: 96%",
            "🔥 SMARTY | بيع | ثقة: 94%"
        };

        for (String signal : topSignals) {
            TextView txt = new TextView(this);
            txt.setText(signal);
            txt.setTextSize(20);
            txt.setPadding(28, 28, 28, 28);
            txt.setTextColor(0xFFFF8800); // برتقالي ناري
            layout.addView(txt);
        }

        setContentView(scroll);
    }
}