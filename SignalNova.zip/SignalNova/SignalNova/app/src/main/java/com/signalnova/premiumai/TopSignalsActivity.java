package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public class TopSignalsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(layout);

        String[] topSignals = {
            "💥 EUR/USD | بيع | 30 ثانية | 🔥🔥🔥🔥🔥",
            "💥 XAU/USD | شراء | 1 دقيقة | 🔥🔥🔥🔥",
            "💥 SMARTY | شراء | 15 ثانية | 🔥🔥🔥🔥🔥"
        };

        for (String signal : topSignals) {
            TextView txt = new TextView(this);
            txt.setText(signal);
            txt.setTextSize(20);
            txt.setPadding(24, 24, 24, 24);
            txt.setTextColor(0xFF00FFFF); // لون أزرق سماوي
            layout.addView(txt);
        }

        setContentView(scroll);
    }
}