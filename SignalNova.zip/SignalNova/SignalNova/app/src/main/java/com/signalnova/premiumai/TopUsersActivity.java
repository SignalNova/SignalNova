package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public class TopUsersActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(layout);

        String[] topUsers = {
            "🥇 Hassan 🇸🇾 | 1470 إحالة | VIP ملكي 🔴",
            "🥈 Tarek 🇪🇬 | 903 إحالة | بلاتيني 🟣",
            "🥉 Nour 🇦🇪 | 732 إحالة | ذهبي 🔵",
            "4️⃣ Rami 🇹🇷 | 630 إحالة | فضي 🟠"
        };

        for (String user : topUsers) {
            TextView txt = new TextView(this);
            txt.setText(user);
            txt.setTextSize(18);
            txt.setPadding(20, 20, 20, 20);
            txt.setTextColor(0xFFFFFF00); // أصفر ملكي
            layout.addView(txt);
        }

        setContentView(scroll);
    }
}
package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ScrollView;

public class TopUsersActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(layout);

        String[] topUsers = {
            "🥇 حسن (Syria) – 298 صفقة ناجحة – VIP 👑",
            "🥈 محمد (UAE) – 255 صفقة ناجحة – VIP 👑",
            "🥉 عمر (KSA) – 232 صفقة – مستخدم ذهبي 🔵",
            "4️⃣ يوسف (Germany) – 218 صفقة – فضي 🟠",
            "5️⃣ نور (Iraq) – 209 صفقة – برونزي 🟤"
        };

        for (String user : topUsers) {
            TextView txt = new TextView(this);
            txt.setText(user);
            txt.setTextSize(18);
            txt.setPadding(20, 20, 20, 20);
            txt.setTextColor(0xFFDDDDDD);
            layout.addView(txt);
        }

        setContentView(scroll);
    }
}