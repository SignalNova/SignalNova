package com.signalnova.premiumai;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public class VideoLessonsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(layout);

        String[] lessons = {
            "🎓 مقدمة في التداول - https://youtu.be/abc123",
            "📊 كيفية قراءة الشموع اليابانية - https://youtu.be/xyz456",
            "💰 إدارة رأس المال الذكية - https://youtu.be/def789",
            "🔥 استراتيجية EMA + RSI - https://youtu.be/ghx345"
        };

        for (String lesson : lessons) {
            TextView txt = new TextView(this);
            txt.setText(lesson);
            txt.setTextSize(18);
            txt.setPadding(24, 24, 24, 24);
            txt.setTextColor(0xFF00FFFF);
            layout.addView(txt);
        }

        setContentView(scroll);
    }
}