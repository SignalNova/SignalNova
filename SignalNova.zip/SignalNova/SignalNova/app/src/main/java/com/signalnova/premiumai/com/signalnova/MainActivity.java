package com.signalnova;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // ضروري يكون عندك ملف activity_main.xml

        TextView title = findViewById(R.id.title);
        title.setText("SignalNova - توصيات ملكية");

        Button btnSignals = findViewById(R.id.btn_signals);
        Button btnSupport = findViewById(R.id.btn_support);
        Button btnToday = findViewById(R.id.btn_today);
        Button btnPerformance = findViewById(R.id.btn_performance);
        Button btnSuggestion = findViewById(R.id.btn_suggestion);

        btnSignals.setOnClickListener(v -> startActivity(new Intent(this, SignalsActivity.class)));
        btnSupport.setOnClickListener(v -> startActivity(new Intent(this, SupportActivity.class)));
        btnToday.setOnClickListener(v -> startActivity(new Intent(this, TodaySignalsActivity.class)));
        btnPerformance.setOnClickListener(v -> startActivity(new Intent(this, PerformanceActivity.class)));
        btnSuggestion.setOnClickListener(v -> startActivity(new Intent(this, FeatureSuggestionActivity.class)));
    }
}